package service;

import java.util.List;

import dto.UserDTO;
import dto.WarningDTO;

public interface WarningService {

    /**
     * MQTT 브로커로부터 전달받은 센서 경고 메시지를 DB안의 warning테이블안에 저장하는 함수
     * topic   MQTT 토픽 (ex: home/livingroom/led/1)
     * message 센서 상태 메시지 (ex: "led_on", "gas_detected")
     */
    void saveWarningData(String topic, String message);
    
 

    /**
     * 로그인된 사용자별로/로그인여부에 따라
     * DB안의 warning테이블에서 특정 센서의 로그 데이터를 조회하여 자바 클라이언트에 리스트로 반환하는 함수
     */
    
    //User테이블의 uesrId와 현재 로그인 유저를 식별해서 
    //Warning테이블안의 sensorId,warningId를 가져와서 
    
    //warning테이블안의 warningDate중 최신경보를 SensorControl로보내는 함수
    List<WarningDTO> loadWarningData(UserDTO userDTO,WarningDTO warningDTO);
}
