package service;

//자바앱으로 라즈베리파이 조작하기 서비스
//자바의 UserSessionDTO로 로그인 세션을 인식후
//로그인된 자바앱 사용자가 라즈베리파이에게 Sensor테이블속 센서id를 클라이언트 아이디를 기준으로 
public interface SensorService {
	

	
	//자바앱(클라2)의 요청을 mqtt를 통해 라즈베리파이 센서(클라1)로 보내기 
	
	//센서 종류 / 번호를 구분해서 
	//센서종류와 번호를 어떻게 구분하지?
	//답 : 데이터베이스의 센서위치 센서id를 기분으로 구분해서
	//토픽보내라
	
	
	//자바앱(클라2)컨트롤러계층의 센서제어 요청을 라즈베리파이(클라1)로 MQTT통신으로 보는 함수
	//장소는 토픽으로 구분하고 센서도 토픽으로 구분해야되나?
	
	//아 내가 로그인여부를 여기서도 깜빡했네
	//당연히 로그인 된 상테에서만 센서를 조작가능해야겠지?
	
	//viewlayer -> controllerlayer -> SensorService(mqtt클라1) -> 라즈베리 os(mqtt클라2) -> 센서조작
	public void controlDevice(String topic,String message);
	
	
	
	

}
