package dao;

public class AdminDAOImpl implements AdminDAO {

}
