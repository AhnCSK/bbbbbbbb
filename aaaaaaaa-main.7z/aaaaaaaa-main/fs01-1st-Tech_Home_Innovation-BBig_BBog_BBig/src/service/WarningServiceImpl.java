package service;

import dao.WarningDAO;
import dto.UserDTO;
import dto.WarningDTO;
import service.WarningService;
import java.time.LocalDateTime;
import java.util.List;

public class WarningServiceImpl implements WarningService {
	
	WarningDTO warningDTO;

    @Override
    public void saveWarningData(String topic, String message) {
    	
    	
    	//sql문이 여기있어야함
    	warningDTO = new WarningDTO(0, message, message, null, message);
    	
    	WarningDTO.selectWarningsByTopic(topic)
        .forEach(System.out::println);
    	
    	WarningDTO.insertWarning(warningDTO);
        System.out.println("[DB 저장 완료] " + warningDTO);
    }

	@Override
	public List<WarningDTO> loadWarningData(UserDTO user, String deviceId) {
		
		if (user.equals("admin")) {
		    // 모든 센서 로그 조회
		} else {
		    // 해당 사용자가 등록한 센서만 조회
		}
		return List<WarningDTO>;
	}


}
