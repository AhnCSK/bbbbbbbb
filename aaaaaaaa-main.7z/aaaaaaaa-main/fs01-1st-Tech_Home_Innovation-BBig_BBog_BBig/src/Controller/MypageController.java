package Controller;

public class MypageController {
	public void showMyPage() {
		
	}

}
