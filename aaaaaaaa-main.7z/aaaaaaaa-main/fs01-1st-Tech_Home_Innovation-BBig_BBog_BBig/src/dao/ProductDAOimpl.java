package dao;

public class ProductDAOImpl implements ProductDAO {

}
