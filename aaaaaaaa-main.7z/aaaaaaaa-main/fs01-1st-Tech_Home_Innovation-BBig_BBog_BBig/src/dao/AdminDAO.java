package dao;

public interface AdminDAO {
	//근데 우리 관리자계정 따로 만들었나?

}
