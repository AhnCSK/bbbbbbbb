package dao;

public class DeviceDAOImpl implements DeviceDAO {

}
