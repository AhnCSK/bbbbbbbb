package dao;

public class SensorDAOImpl implements SensorDAO {

}
