package view;

public class MenuUi {

}
