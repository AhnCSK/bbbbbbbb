package dao;

import dto.WarningDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WarningDAOImpl implements WarningDAO {
	
	private static final String URL = "jdbc:mysql://localhost:3306/smart_home_system";
    private static final String USER = "sample";
    private static final String PASSWORD = "1234"; // 필요 시 수정

    
    //라즈베리파이의 센서정보를 mqtt통신으로 WarningDAOImpl에
    //가져와서 데이터베이스에 저장하기
    
	//라즈베리파이 클라이언트하나당 mqtt통신시 
	//센서와 디바이스는 데이터 베이스안의 
	//sensor_id를 토픽으로 mqtt통신하고
	
	//자바클라이언트는 은 로그인유저의 정보의 유저id를 테이블에서 가져와서 토픽으로 만들어서 통신할까?
    
	@Override
	public void insertWarning(WarningDTO warningDTO) {
		
		
		
		String sql = "INSERT INTO warning (warning_id, sensor_id, message, warning_date) VALUES (?, ?, ?, ?)";
		
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, warningDTO.getTopic());
            pstmt.setString(2, warningDTO.getMessage());
            pstmt.setTimestamp(3, Timestamp.valueOf(warningDTO.getTimestamp()));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}

	//데이터베이스에 저장된 메시지를 사용자가 가져와서 자바앱으로 보여주기
	//아니 그럼 여기에 토픽 매개변수는 필요없지 않나?
	@Override
	public List<WarningDTO> selectWarningsByTopic(String topic) {
		 List<WarningDTO> list = new ArrayList<>();
		 
	        String sql = "SELECT * FROM warning WHERE sensor_id = ? ORDER BY timestamp DESC";
	        
	        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, topic);
	            ResultSet rs = pstmt.executeQuery();
	            while (rs.next()) {
	                list.add(new WarningDTO(
	                    rs.getString("topic"),
	                    rs.getString("message"),
	                    rs.getTimestamp("timestamp").toLocalDateTime()
	                ));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return list;
	}

}
