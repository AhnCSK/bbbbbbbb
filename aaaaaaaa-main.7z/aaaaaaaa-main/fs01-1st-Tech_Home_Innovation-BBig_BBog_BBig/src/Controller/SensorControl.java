package Controller;

import mqtt.MqttManager;

public class SensorControl {
	private MqttManager mqttManager;
	
//	public void ledSensor(2) {
//		if 1:
//		mqttManager = new MqttManager("");
//		mqttManager.publish("home/test", "led_off");
//		
//		2:
//			led 
//	}
}
