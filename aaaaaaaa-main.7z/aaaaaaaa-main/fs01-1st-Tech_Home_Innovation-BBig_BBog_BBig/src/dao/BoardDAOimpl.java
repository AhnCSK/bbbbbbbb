package dao;

public class BoardDAOImpl implements BoardDAO {

}
