package dao;

public class OrderDAOImpl implements OrderDAO {

}
